import {
  BadRequestException,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';

import { JwtService } from '@nestjs/jwt';
import { PrismaService } from '../../prisma/prisma.service';
import * as bcrypt from 'bcrypt';
import type { RegisterOwnerDto } from './dto/register-owner.dto';
import type { LoginDto } from './dto/login.dto';
import type { JwtPayload } from './types/jwt-payload.type';

type AuthResponse = { accessToken: string };

@Injectable()
export class AuthService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly jwt: JwtService,
  ) {}

  /**
   * Creates a new tenant + the first OWNER user.
   * This is the SaaS onboarding entry point.
   */
  async registerOwner(input: RegisterOwnerDto): Promise<AuthResponse> {
    const { tenantName, tenantSlug, fullName, email, password } = input;

    // 1) Ensure tenant slug is unique (SaaS: each shop must be unique)
    const existingTenant = await this.prisma.tenant.findUnique({
      where: { slug: tenantSlug },
    });
    if (existingTenant) {
      throw new BadRequestException('Tenant slug already exists');
    }

    // 2) Hash password (never store plain password)
    const passwordHash = await bcrypt.hash(password, 10);

    // 3) Create tenant + user in a transaction (either both succeed or both fail)
    const result = await this.prisma.$transaction(async (tx) => {
      const tenant = await tx.tenant.create({
        data: { name: tenantName, slug: tenantSlug },
      });

      const user = await tx.user.create({
        data: {
          tenantId: tenant.id,
          fullName,
          email,
          passwordHash,
          role: 'OWNER',
        },
      });

      return { tenant, user };
    });

    return this.issueToken({
      sub: result.user.id.toString(),
      tenantId: result.user.tenantId.toString(),
      role: result.user.role,
      email: result.user.email,
    });
  }

  /**
   * Logs a user into a specific tenant using tenantSlug + email + password.
   * This prevents mixing accounts across different shops.
   */
  async login(input: LoginDto): Promise<AuthResponse> {
    const { tenantSlug, email, password } = input;

    // 1) Find tenant by slug
    const tenant = await this.prisma.tenant.findUnique({
      where: { slug: tenantSlug },
    });
    if (!tenant) {
      throw new UnauthorizedException('Invalid login');
    }

    // 2) Find user inside that tenant (composite unique: tenantId + email)
    const user = await this.prisma.user.findUnique({
      where: {
        tenantId_email: {
          tenantId: tenant.id,
          email,
        },
      },
    });

    if (!user || !user.isActive) {
      throw new UnauthorizedException('Invalid login');
    }

    // 3) Compare password hash
    const ok = await bcrypt.compare(password, user.passwordHash);
    if (!ok) {
      throw new UnauthorizedException('Invalid login');
    }

    return this.issueToken({
      sub: user.id.toString(),
      tenantId: user.tenantId.toString(),
      role: user.role,
      email: user.email,
    });
  }

  /**
   * Signs a JWT token. We keep this strongly typed (JwtPayload) so ESLint doesn't complain.
   */
  private issueToken(payload: JwtPayload): AuthResponse {
    return { accessToken: this.jwt.sign(payload) };
  }
}
