import { Controller, Get, Post, Body, UseGuards } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { AuthService } from './auth.service';
import { RegisterOwnerDto } from './dto/register-owner.dto';
import { LoginDto } from './dto/login.dto';
import { CurrentUser } from './decorators/current-user.decorator';
import type { JwtPayload } from './types/jwt-payload.type';

@Controller()
export class AuthController {
  constructor(private auth: AuthService) {}

  @Post('/auth/register-owner')
  registerOwner(@Body() body: RegisterOwnerDto) {
    return this.auth.registerOwner(body);
  }

  @Post('/auth/login')
  login(@Body() body: LoginDto) {
    return this.auth.login(body);
  }

  @UseGuards(AuthGuard('jwt'))
  @Get('/me')
  me(@CurrentUser() user: JwtPayload) {
    return { user };
  }
}
